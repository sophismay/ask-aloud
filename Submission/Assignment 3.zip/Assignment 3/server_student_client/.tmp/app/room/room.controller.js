'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {
  var RoomController = function () {
    function RoomController($http, $scope, socket) {
      _classCallCheck(this, RoomController);

      this.$http = $http;
      this.socket = socket;
      this.rooms = [];
      alert('ADD THING');
      //$scope.$on('$destroy', function() {
      //  socket.unsyncUpdates('thing');
      //});
    }

    _createClass(RoomController, [{
      key: 'joinRoom',
      value: function joinRoom() {}
    }, {
      key: 'addThing',
      value: function addThing() {
        e.preventDefault();
        console.log('CLICKED');
        alert('ADD THING');
      }

      /*$onInit() {
        this.$http.get('/api/things')
          .then(response => {
            this.awesomeThings = response.data;
            this.socket.syncUpdates('thing', this.awesomeThings);
          });
      }*/

      /*addRoom() {
        if (this.newRoom) {
          this.$http.post('/api/rooms', {
            name: this.newRoom
          });
          this.newRoom = '';
        }
      }*/

    }]);

    return RoomController;
  }();

  angular.module('csappApp').component('room', {
    templateUrl: 'app/room/room.html',
    controller: RoomController
  });
})();
//# sourceMappingURL=room.controller.js.map
