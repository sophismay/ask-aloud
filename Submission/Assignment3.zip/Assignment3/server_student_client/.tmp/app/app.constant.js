'use strict';

(function (angular, undefined) {
  'use strict';

  angular.module('csappApp.constants', []).constant('appConfig', { userRoles: ['guest', 'user', 'admin'] });
})(angular);
//# sourceMappingURL=app.constant.js.map
