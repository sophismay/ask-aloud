Server and student client:
1. Run `npm install` in the server_student_client folder to install server dependencies.
2. Run `grunt serve` in the server_student_client folder to start the development server. It should automatically open the client in your browser when ready.

Lecturer-Client:
The Lecturer-Client is a C# application. Simply open the file Assignment3.sln from the LecturererDesktopClient folder in Visual Studio 2015 and 
run it from the IDE. Please note that Visual Studio will download some NuGet packages when running the application for the first time. 
It might be necessary to restart Visual Studio in order for all dependancies to be found correctly.